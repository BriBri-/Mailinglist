<?php
include_once('include/initialization.php');
$_SESSION['admin_secret'] = null;
redirectTo('admin.php');
?>
