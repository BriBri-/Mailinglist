<?php
$host = 'localhost';
$dbname = 'mailinglist';
$user = 'root';
$password = '';


